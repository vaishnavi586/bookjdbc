package co.book.entity;

public class Book {
	private int id;
	private String Name;
	private String author;
	private String publishedyear;
	private String cost;
	public Book() {
		
	}

	public Book(int id, String name, String author, String publishedyear, String cost) {
		
		this.id = id;
		this.Name = name;
		this.author = author;
		this.publishedyear = publishedyear;
		this.cost = cost;
	}

	
	

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getPublishedyear() {
		return publishedyear;
	}
	public void setPublishedyear(String publishedyear) {
		this.publishedyear = publishedyear;
	}
	public String getCost() {
		return cost;
	}
	public void setCost(String cost) {
		this.cost = cost;
	}
	@Override
	public String toString() {
		return "Book [id=" + id + ", Name=" + Name + ", author=" + author + ", publishedyear=" + publishedyear
				+ ", cost=" + cost + "]";
	}


}
