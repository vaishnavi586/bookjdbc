package co.book.tests;

import co.book.dao.DaoException;
import co.book.dao.BookDao;
import co.book.dao.impl.JdbcBookDao;
import co.book.entity.Book;

public class GetOneBook {
public static void main(String[] args) throws DaoException {
		
		BookDao dao = new JdbcBookDao();
		
		int id = 102;
		Book p = dao.getBook(id);
		if(p==null){
			System.out.println("No data found");
		}
		else {
			System.out.println(p);
		}
		
	}
}
