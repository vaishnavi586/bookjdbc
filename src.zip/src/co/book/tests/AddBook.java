package co.book.tests;

import co.book.dao.DaoException;
import co.book.dao.BookDao;
import co.book.dao.impl.JdbcBookDao;
import co.book.entity.Book;

public class AddBook {
	public static void main(String[] args) throws DaoException {

		Book book = new Book(101, "the secret", "rhymondbrine", "1982",
				"750");

		BookDao dao = new JdbcBookDao();
		dao.addBook(book);
		System.out.println("book data added to db.");
		
	}
}
