package co.book.tests;

import co.book.dao.DaoException;
import co.book.dao.BookDao;
import co.book.dao.impl.JdbcBookDao;

public class Delete {

public static void main(String[] args) throws DaoException {
		
		BookDao dao = new JdbcBookDao();
		int id=102;
		
		dao.deleteBook(id);
		System.out.println("Succeeded!");
	}
}
