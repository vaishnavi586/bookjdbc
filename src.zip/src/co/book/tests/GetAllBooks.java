package co.book.tests;


	import java.util.List;

	import co.book.dao.DaoException;
	import co.book.dao.BookDao;
	import co.book.dao.impl.JdbcBookDao;
	import co.book.entity.Book;
	public class GetAllBooks {
	

		public static void main(String[] args) throws DaoException {
			BookDao dao = new JdbcBookDao();

			List<Book> list = dao.getAllBooks();
			for (Book p : list) {
				System.out.println(p.getName() 
						+ " " + p.getAuthor());
			}
		}
}
