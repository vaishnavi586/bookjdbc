package co.book.dao.impl;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import co.book.dao.DaoException;
import co.book.dao.BookDao;
import co.book.entity.Book;
import co.book.util.DbUtil;


public class JdbcBookDao implements BookDao{
	@Override
	public void addBook(Book book) throws DaoException {
		Connection conn = null;
		PreparedStatement stmt = null;
		try {
			String sql = "insert into book values(?,?,?,?,?)";
			conn = DbUtil.getConnection();			
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, book.getId());
			stmt.setString(2, book.getName());
			stmt.setString(3, book.getAuthor());
			stmt.setString(4, book.getPublishedyear());
			stmt.setString(5, book.getCost());
			stmt.executeUpdate();
		} catch (Exception e) {
			throw new DaoException(e);
		} finally {
			DbUtil.releaseResource(conn, stmt, null);
		}
	}
	@Override
	public Book getBook(int id) throws DaoException {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			String sql = "select * from book where id=?";
			conn = DbUtil.getConnection();			
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, id);
			rs = stmt.executeQuery();
			if(rs.next()){
				Book book = getBookFromResultSet(rs);
				return book;
			}
			
		} catch (Exception e) {
			throw new DaoException(e);
		} finally {
			DbUtil.releaseResource(conn, stmt, rs);
		}
		return null;
	}
	
	@Override
	public void updateBook(Book book) throws DaoException {

	}
	@Override
	public void deleteBook(int id) throws DaoException {
		Connection conn = null;
		PreparedStatement stmt = null;
		try {
			String sql = "delete from book where id= ?";
			conn = DbUtil.getConnection();			
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, id);
			if(stmt.executeUpdate()==0){
				throw new DaoException("No data found!");
			}
		} catch (Exception e) {
			throw new DaoException(e);
		} finally {
			DbUtil.releaseResource(conn, stmt, null);
		}
	}
	@Override
	public List<Book> getAllBooks() throws DaoException {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		List<Book> list = new ArrayList<>();
		
		try {
			String sql = "select * from book";
			conn = DbUtil.getConnection();			
			stmt = conn.prepareStatement(sql);
			rs = stmt.executeQuery();

			while(rs.next()){
				Book book = getBookFromResultSet(rs);
				list.add(book);
			}
			
		} catch (Exception e) {
			throw new DaoException(e);
		} finally {
			DbUtil.releaseResource(conn, stmt, rs);
		}
		return list;
	}

	@Override
	public Book getBookByauthor(String author) throws DaoException {
		return null;
	}
	private Book getBookFromResultSet(ResultSet rs) throws SQLException {
	Book book =new Book();
	book.setId(rs.getInt("id"));
		book.setName(rs.getString("name"));
		book.setAuthor(rs.getString("author"));
		book.setPublishedyear(rs.getString("publishedyear"));
		book.setCost(rs.getString("cost"));
		return book;
	}
	
}






