package co.book.dao;
import java.util.List;
import co.book.entity.Book;
import co.book.dao.DaoException;


public interface BookDao {
	
	// CRUD operations
	public  void addBook(Book book) throws DaoException;
	public Book getBook(int id) throws DaoException;
	public void updateBook(Book book) throws DaoException;
	public void deleteBook(int id) throws DaoException; 
		
		// Queries
	public List<Book> getAllBooks() throws DaoException;
	public Book getBookByauthor(String author) throws DaoException;
		

}
